// Menú responsive para dispositivos móviles.
const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

menuBtn.addEventListener("click", () => {
  navLinks.classList.toggle("active");
});

// Cierra el menú al seleccionar una sección.
document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("active");
  });
});

// Actualiza automáticamente el año del footer.
document.getElementById("year").textContent = new Date().getFullYear();
