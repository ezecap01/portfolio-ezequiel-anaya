# Portfolio Web — Ezequiel Anaya

Portfolio profesional desarrollado para el **Trabajo Práctico N.º 8: Tu Identidad Digital - Portfolio en GitHub Pages**, correspondiente a la asignatura Formación en Ambiente de Trabajo (FAT), 7.º I - Programación, IPET 247.

## Objetivo

El proyecto funciona como una presentación profesional de mi perfil como estudiante de la Tecnicatura en Programación. Incluye información sobre mi formación, habilidades tecnológicas y proyectos realizados durante el ciclo orientado.

El sitio está pensado para demostrar conocimientos relacionados con:

- Desarrollo web.
- Organización y documentación de código.
- Diseño responsive.
- Control de versiones con Git/GitHub.
- Publicación de sitios mediante GitHub Pages.
- Programación.
- Bases de datos y lógica backend.

## Tecnologías utilizadas

- **HTML5** — estructura y contenido.
- **CSS3** — diseño visual y responsive design.
- **JavaScript** — interactividad del menú y funcionalidades simples.
- **Git / GitHub** — control de versiones y almacenamiento del código.
- **GitHub Pages** — publicación del sitio.
- **Oracle APEX / SQL / PL/SQL** — utilizados en uno de los proyectos documentados.

## Estructura

```text
portfolio-ezequiel-anaya/
│
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    └── script.js
```

## Proyectos destacados

### 1. Sistema de gestión de videojuegos
Proyecto orientado a backend y bases de datos realizado con Oracle APEX y Oracle SQL/PLSQL. Incluye operaciones de gestión, auditoría y un trigger para registrar acciones.

Este proyecto se incorpora como evidencia relacionada con la **Oferta B: Desarrollador/a de Software - Gestión de Stock**, ya que demuestra conocimientos de lógica de datos, consultas, procedimientos y gestión de información.

### 2. Game Hub
Aplicación desarrollada con Python y Kivy que reúne diferentes juegos y utiliza lógica de programación para gestionar la interacción.

### 3. Web de comunidad y administración
Sitio web realizado para el proyecto Spawn Point, destinado a presentar y organizar información de la empresa y su comunidad.

## GitHub Pages

Una vez creado el repositorio público, activar:

**Settings → Pages → Deploy from a branch → main → /root → Save**

La URL tendrá una estructura similar a:

```text
https://TU-USUARIO.github.io/NOMBRE-DEL-REPOSITORIO/
```

Reemplazar la URL anterior por la dirección real una vez realizado el despliegue.

## Autor

**Ezequiel Anaya**  
7.º I — Programación  
IPET 247  
Córdoba, Argentina

## Estado

Portfolio desarrollado para fines académicos y de presentación profesional.
